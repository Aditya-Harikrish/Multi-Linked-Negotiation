# Multi-Linked-Negotiation

## Installation
```
pip install -r requirements.txt
```